# Luis Inversiones — prototipo
Abre `index.html` en un navegador.

Incluye:
- Inicio de sesión y registro
- Dashboard
- Portafolio
- Mercados
- Movimientos
- Perfil y seguridad
- Diseño responsive para móvil y escritorio
- Acciones y notificaciones simuladas

Nota: es un prototipo frontend. No procesa dinero real ni garantiza rendimientos. Para producción se requiere backend seguro, base de datos, autenticación real, KYC/AML, proveedor de pagos/custodia, datos de mercado, auditoría, privacidad, términos y cumplimiento regulatorio aplicable.
